
# Secure Authentication Lab

## Project Description
This project is a Python Flask-based authentication system that provides secure user registration and login.

## Features
- User Registration
- User Login and Logout
- Password Hashing
- Session Management
- CSRF Protection
- Login Attempt Limiting
- Protected Dashboard

## Technologies Used
- Python
- Flask
- SQLite
- Flask-Session
- Flask-WTF

## Installation

1. Install Python.
2. Open the project folder.
3. Create a virtual environment:

   py -m venv venv

4. Activate the environment:

   .\venv\Scripts\Activate.ps1

5. Install dependencies:

   py -m pip install -r requirements.txt

## Run the Project

py app.py

Open your browser and visit:

http://127.0.0.1:5000

## Testing
The application was tested for registration, login, logout, invalid password attempts, and protected dashboard access.
