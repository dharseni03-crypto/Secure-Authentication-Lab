
import sqlite3
import re
from datetime import timedelta
from flask import Flask, request, redirect, session, render_template_string
from werkzeug.security import generate_password_hash, check_password_hash
from flask_session import Session
from pathlib import Path
import secrets
import os
import time
from flask_wtf.csrf import CSRFProtect, generate_csrf

app = Flask(__name__)
app.config["SECRET_KEY"] = "d0b539582af83f8264681ccad842164e1f0966b05471542be2d9d5196af195ec"
csrf = CSRFProtect(app)

app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY", secrets.token_hex(32)
)
app.config["SESSION_TYPE"] = "filesystem"
app.config["SESSION_FILE_DIR"] = ".sessions"
app.config["SESSION_PERMANENT"] = True
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = False
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(minutes=15)

Path(".sessions").mkdir(exist_ok=True)
Session(app)

def database():
    return sqlite3.connect("users.db")

with database() as db:
    db.execute("""
    CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    db.execute("""
    CREATE TABLE IF NOT EXISTS attempts(
        username TEXT PRIMARY KEY,
        count INTEGER,
        last_time REAL
    )
    """)
def page(title, content):
    token = generate_csrf()

    content = content.replace(
        '<form method="POST" action="/logout">',
        '<form method="POST" action="/logout"><input type="hidden" name="csrf_token" value="' + token + '">'
    )

    content = content.replace(
        '<form method="POST">',
        '<form method="POST"><input type="hidden" name="csrf_token" value="' + token + '">'
    )

    return render_template_string(
        "<h2>{{ title }}</h2>{{ content|safe }}",
        title=title,
        content=content
    )
@app.route("/")
def home():
    if "user" in session:
        return redirect("/dashboard")
    return redirect("/login")

@app.route("/register", methods=["GET", "POST"])
def register():
    message = ""

    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]

        if not re.fullmatch(r"[A-Za-z0-9_]{3,30}", username):
            message = "Invalid username!"
        elif len(password) < 12 or len(password) > 128:
            message = "Password must be 12-128 characters!"
        else:
            hashed = generate_password_hash(password)

            try:
                with database() as db:
                    db.execute(
                        "INSERT INTO users(username,password) VALUES(?,?)",
                        (username, hashed)
                    )
                message = "Registration successful!"
            except sqlite3.IntegrityError:
                message = "Unable to create account. Try another username."

    return page("Register", """
    <p style="color:red">""" + message + """</p>
    <form method="POST">
    <input name="username" placeholder="Username" required>
    <input name="password" type="password" placeholder="Password" required>
    <button>Register</button>
    </form>
    <a href="/login">Login</a>
    """)

@app.route("/login", methods=["GET", "POST"])
def login():
    message = ""

    if request.method == "POST":
        username = request.form["username"].strip()
        password = request.form["password"]

        now = time.time()

        with database() as db:
            row = db.execute(
                "SELECT count,last_time FROM attempts WHERE username=?",
                (username,)
            ).fetchone()

            if row and now - row[1] < 600 and row[0] >= 5:
                message = "Too many attempts. Try later."
            else:
                user = db.execute(
                    "SELECT * FROM users WHERE username=?",
                    (username,)
                ).fetchone()

                if user and check_password_hash(user[2], password):
                    db.execute(
                        "DELETE FROM attempts WHERE username=?",
                        (username,)
                    )
                    session.clear()
                    session.permanent = True
                    session["user"] = username
                    return redirect("/dashboard")

                count = row[0] + 1 if row and now-row[1] < 600 else 1

                db.execute("""
                    INSERT OR REPLACE INTO attempts
                    VALUES(?,?,?)
                """, (username, count, now))

                message = "Invalid username or password."

    return page("Login", """
    <p style="color:red">""" + message + """</p>
    <form method="POST">
    <input name="username" placeholder="Username" required>
    <input name="password" type="password" placeholder="Password" required>
    <button>Login</button>
    </form>
    <a href="/register">Create Account</a>
    """)

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/login")

    return page("Dashboard", """
    <h3>Welcome! You are logged in.</h3>
    <form method="POST" action="/logout">
    <input type="hidden" name="csrf_token" value="{{ csrf_token() }}">
    <button type="submit">Logout</button>
</form>
    """)

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect("/login")

if __name__ == "__main__":
    app.run(debug=False)
